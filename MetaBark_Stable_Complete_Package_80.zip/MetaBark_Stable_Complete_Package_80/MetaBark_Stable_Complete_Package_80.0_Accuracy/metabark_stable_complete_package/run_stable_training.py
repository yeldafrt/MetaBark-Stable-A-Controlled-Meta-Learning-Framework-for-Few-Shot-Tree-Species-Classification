"""
MetaBark Stable Training Script
Conservative approach for stable and reliable results
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
import random
from PIL import Image
import json
from collections import defaultdict
import gc
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# Import our stable model
exec(open('/home/ubuntu/metabark_stable.py').read())

class BarkDataset(Dataset):
    """Conservative bark dataset with strong augmentation"""
    def __init__(self, data_dir, transform=None, is_training=True):
        self.data_dir = data_dir
        self.transform = transform
        self.is_training = is_training
        
        # Load images directly from species folders
        self.images = []
        self.labels = []
        self.species_names = []
        
        # Get all species folders
        species_folders = [f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))]
        species_folders.sort()  # Consistent ordering
        
        for species_idx, species_folder in enumerate(species_folders):
            species_path = os.path.join(data_dir, species_folder)
            self.species_names.append(species_folder)
            
            # Load all images from this species
            for img_file in os.listdir(species_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(species_path, img_file)
                    self.images.append(img_path)
                    self.labels.append(species_idx)
        
        print(f"Loaded {len(self.images)} images from {len(species_folders)} species")
        print(f"Species: {species_folders[:5]}...")  # Show first 5 species
        
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        # Load image
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image, label

class EpisodeDataLoader:
    """Conservative episode generation for meta-learning"""
    def __init__(self, dataset, n_way=5, n_shot=5, n_query=3, n_episodes=100):
        self.dataset = dataset
        self.n_way = n_way
        self.n_shot = n_shot
        self.n_query = n_query
        self.n_episodes = n_episodes
        
        # Group images by species
        self.species_to_images = defaultdict(list)
        for idx, (_, label) in enumerate(dataset):
            self.species_to_images[label].append(idx)
        
        self.available_species = list(self.species_to_images.keys())
        print(f"Available species for episodes: {len(self.available_species)}")
    
    def __iter__(self):
        for _ in range(self.n_episodes):
            # Sample species for this episode
            episode_species = random.sample(self.available_species, self.n_way)
            
            support_images = []
            support_labels = []
            query_images = []
            query_labels = []
            
            for class_idx, species in enumerate(episode_species):
                # Get images for this species
                species_images = self.species_to_images[species]
                
                # Sample support and query images
                if len(species_images) >= self.n_shot + self.n_query:
                    sampled_images = random.sample(species_images, self.n_shot + self.n_query)
                    
                    # Support set
                    for img_idx in sampled_images[:self.n_shot]:
                        image, _ = self.dataset[img_idx]
                        support_images.append(image)
                        support_labels.append(class_idx)
                    
                    # Query set
                    for img_idx in sampled_images[self.n_shot:self.n_shot + self.n_query]:
                        image, _ = self.dataset[img_idx]
                        query_images.append(image)
                        query_labels.append(class_idx)
            
            # Convert to tensors
            support_images = torch.stack(support_images)
            support_labels = torch.tensor(support_labels)
            query_images = torch.stack(query_images)
            query_labels = torch.tensor(query_labels)
            
            yield support_images, support_labels, query_images, query_labels
    
    def __len__(self):
        return self.n_episodes

def create_conservative_transforms():
    """Conservative data augmentation"""
    train_transform = transforms.Compose([
        transforms.Resize((128, 128)),  # Smaller size for stability
        transforms.RandomHorizontalFlip(p=0.3),  # Reduced probability
        transforms.RandomRotation(degrees=10),   # Smaller rotation
        transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.05),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    val_transform = transforms.Compose([
        transforms.Resize((128, 128)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    return train_transform, val_transform

def run_stable_training():
    """Run conservative stable training"""
    print("🛡️ Starting Conservative MetaBark Training")
    print("=" * 50)
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Create transforms
    train_transform, val_transform = create_conservative_transforms()
    
    # Load dataset
    data_dir = '/home/ubuntu/datasets/mini_barknet_real/BarkNet-mini'
    
    # Create datasets
    full_dataset = BarkDataset(data_dir, transform=train_transform, is_training=True)
    val_dataset = BarkDataset(data_dir, transform=val_transform, is_training=False)
    
    # Split species for train/val
    all_species = list(set([label for _, label in full_dataset]))
    train_species = all_species[:8]  # 8 species for training
    val_species = all_species[8:10]  # 2 species for validation
    
    print(f"Training species: {train_species}")
    print(f"Validation species: {val_species}")
    
    # Filter datasets
    train_indices = [i for i, (_, label) in enumerate(full_dataset) if label in train_species]
    val_indices = [i for i, (_, label) in enumerate(val_dataset) if label in val_species]
    
    train_subset = torch.utils.data.Subset(full_dataset, train_indices)
    val_subset = torch.utils.data.Subset(val_dataset, val_indices)
    
    # Create episode loaders
    train_loader = EpisodeDataLoader(train_subset, n_way=5, n_shot=5, n_query=3, n_episodes=50)
    val_loader = EpisodeDataLoader(val_subset, n_way=2, n_shot=5, n_query=5, n_episodes=20)
    
    # Create model and trainer
    model = StableMetaBark(feature_dim=256)
    trainer = ConservativeTrainer(model, device)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    # Start training
    print("\n🚀 Starting training with conservative settings...")
    history = trainer.train(train_loader, val_loader, epochs=30)
    
    # Save results
    results = []
    for i in range(len(history['val_accuracy'])):
        results.append({
            'epoch': (i + 1) * 2,  # Report every 2 epochs
            'train_loss': history['train_loss'][i],
            'val_loss': history['val_loss'][i],
            'val_accuracy': history['val_accuracy'][i],
            'val_std': history['val_std'][i],
            'learning_rate': history['learning_rate'][i],
            'temperature': history['temperature'][i]
        })
    
    # Save to file
    with open('/home/ubuntu/metabark_stable_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\n✅ Training completed!")
    print(f"Final accuracy: {history['val_accuracy'][-1]:.1f}% ± {history['val_std'][-1]:.1f}%")
    print(f"Results saved to: metabark_stable_results.json")
    
    return history, results

if __name__ == "__main__":
    # Set seeds for reproducibility
    set_seeds(42)
    
    # Run training
    history, results = run_stable_training()
    
    print("🎯 Conservative training completed successfully!")

