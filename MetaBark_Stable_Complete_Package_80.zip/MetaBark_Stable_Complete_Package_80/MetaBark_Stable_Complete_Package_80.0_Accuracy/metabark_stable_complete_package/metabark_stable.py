"""
MetaBark Stable: Ultra-Conservative Configuration for Stable Training
Focus on reliability and reproducibility over peak performance
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import numpy as np
import os
import random
from PIL import Image
import json
from collections import defaultdict
import gc
from sklearn.model_selection import KFold
import warnings
warnings.filterwarnings('ignore')

# Set seeds for reproducibility
def set_seeds(seed=42):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seeds(42)

class StableMetaBark(nn.Module):
    """Ultra-stable MetaBark with conservative design"""
    def __init__(self, feature_dim=256):  # Reduced from 512 to 256
        super().__init__()
        
        # Conservative backbone with more frozen layers
        from torchvision.models import resnet18, ResNet18_Weights
        self.backbone = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
        
        # Freeze more layers for stability
        for param in self.backbone.conv1.parameters():
            param.requires_grad = False
        for param in self.backbone.bn1.parameters():
            param.requires_grad = False
        for param in self.backbone.layer1.parameters():
            param.requires_grad = False
        for param in self.backbone.layer2.parameters():
            param.requires_grad = False  # Freeze layer2 too
        
        self.backbone.fc = nn.Identity()
        
        # Simplified feature processing with strong regularization
        self.feature_processor = nn.Sequential(
            nn.Linear(512, feature_dim),
            nn.BatchNorm1d(feature_dim),
            nn.ReLU(),
            nn.Dropout(0.6),  # Increased dropout
            nn.Linear(feature_dim, feature_dim),
            nn.BatchNorm1d(feature_dim),
            nn.ReLU(),
            nn.Dropout(0.5)   # Strong regularization
        )
        
        # Simplified attention with fewer heads
        self.self_attention = nn.MultiheadAttention(
            embed_dim=feature_dim,
            num_heads=4,  # Reduced from 8 to 4
            dropout=0.3,
            batch_first=True
        )
        
        # Smaller enhancement network
        self.enhancer = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),  # No expansion
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(feature_dim, feature_dim)
        )
        
        # Conservative temperature initialization
        self.temperature = nn.Parameter(torch.tensor(5.0))  # Lower initial value
        
    def extract_features(self, x):
        """Conservative feature extraction"""
        # Backbone features
        features = self.backbone(x)
        
        # Feature processing
        processed = self.feature_processor(features)
        
        # Self-attention
        batch_size = processed.size(0)
        processed_reshaped = processed.unsqueeze(1)
        
        attended, _ = self.self_attention(processed_reshaped, processed_reshaped, processed_reshaped)
        attended = attended.squeeze(1)
        
        # Conservative enhancement
        enhanced = self.enhancer(attended)
        final_features = processed + 0.5 * enhanced  # Reduced residual weight
        
        # L2 normalization
        final_features = F.normalize(final_features, p=2, dim=1)
        
        return final_features
    
    def prototypical_forward(self, support_images, support_labels, query_images):
        """Stable prototypical networks"""
        # Extract features
        support_features = self.extract_features(support_images)
        query_features = self.extract_features(query_images)
        
        # Create prototypes
        unique_labels = torch.unique(support_labels)
        prototypes = []
        
        for label in unique_labels:
            mask = support_labels == label
            prototype = support_features[mask].mean(dim=0)
            prototypes.append(prototype)
        
        prototypes = torch.stack(prototypes)
        
        # Calculate distances with temperature scaling
        distances = torch.cdist(query_features, prototypes)
        
        # Conservative temperature clipping
        temp = torch.clamp(self.temperature, min=1.0, max=10.0)
        logits = -distances / temp
        
        return logits

class ConservativeTrainer:
    """Ultra-conservative training strategy"""
    def __init__(self, model, device):
        self.model = model.to(device)
        self.device = device
        
        # Conservative optimizer settings
        self.optimizer = torch.optim.Adam(
            model.parameters(), 
            lr=5e-6,  # Very low learning rate
            weight_decay=1e-4,  # L2 regularization
            betas=(0.9, 0.999)
        )
        
        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, 
            mode='min', 
            factor=0.5, 
            patience=5
        )
        
        # Early stopping
        self.best_val_loss = float('inf')
        self.patience_counter = 0
        self.patience = 10
        
        # Training history
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'val_accuracy': [],
            'val_std': [],
            'learning_rate': [],
            'temperature': []
        }
    
    def train_epoch(self, train_loader):
        """Conservative training epoch"""
        self.model.train()
        total_loss = 0
        num_batches = 0
        
        for batch_idx, (support_images, support_labels, query_images, query_labels) in enumerate(train_loader):
            # Move to device
            support_images = support_images.to(self.device)
            support_labels = support_labels.to(self.device)
            query_images = query_images.to(self.device)
            query_labels = query_labels.to(self.device)
            
            # Forward pass
            logits = self.model.prototypical_forward(support_images, support_labels, query_images)
            loss = F.cross_entropy(logits, query_labels)
            
            # Backward pass with gradient clipping
            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
            
            # Memory cleanup
            if batch_idx % 10 == 0:
                torch.cuda.empty_cache()
        
        return total_loss / num_batches
    
    def validate(self, val_loader):
        """Conservative validation"""
        self.model.eval()
        total_loss = 0
        accuracies = []
        
        with torch.no_grad():
            for support_images, support_labels, query_images, query_labels in val_loader:
                # Move to device
                support_images = support_images.to(self.device)
                support_labels = support_labels.to(self.device)
                query_images = query_images.to(self.device)
                query_labels = query_labels.to(self.device)
                
                # Forward pass
                logits = self.model.prototypical_forward(support_images, support_labels, query_images)
                loss = F.cross_entropy(logits, query_labels)
                
                # Calculate accuracy
                predictions = torch.argmax(logits, dim=1)
                accuracy = (predictions == query_labels).float().mean().item()
                
                total_loss += loss.item()
                accuracies.append(accuracy)
        
        val_loss = total_loss / len(val_loader)
        val_accuracy = np.mean(accuracies)
        val_std = np.std(accuracies)
        
        return val_loss, val_accuracy, val_std
    
    def train(self, train_loader, val_loader, epochs=50):
        """Conservative training loop"""
        print("Starting conservative training...")
        print(f"Target: Stable accuracy with std < 10%")
        
        for epoch in range(epochs):
            # Training
            train_loss = self.train_epoch(train_loader)
            
            # Validation
            val_loss, val_accuracy, val_std = self.validate(val_loader)
            
            # Update scheduler
            self.scheduler.step(val_loss)
            
            # Record history
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['val_accuracy'].append(val_accuracy * 100)
            self.history['val_std'].append(val_std * 100)
            self.history['learning_rate'].append(self.optimizer.param_groups[0]['lr'])
            self.history['temperature'].append(self.model.temperature.item())
            
            # Early stopping check
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.patience_counter = 0
                # Save best model
                torch.save(self.model.state_dict(), '/home/ubuntu/metabark_stable_best.pth')
            else:
                self.patience_counter += 1
            
            # Print progress
            print(f"Epoch {epoch+1:2d}: "
                  f"Train Loss: {train_loss:.4f}, "
                  f"Val Loss: {val_loss:.4f}, "
                  f"Val Acc: {val_accuracy*100:.1f}% ± {val_std*100:.1f}%, "
                  f"LR: {self.optimizer.param_groups[0]['lr']:.2e}, "
                  f"Temp: {self.model.temperature.item():.2f}")
            
            # Early stopping
            if self.patience_counter >= self.patience:
                print(f"Early stopping at epoch {epoch+1}")
                break
            
            # Memory cleanup
            torch.cuda.empty_cache()
            gc.collect()
        
        # Load best model
        self.model.load_state_dict(torch.load('/home/ubuntu/metabark_stable_best.pth'))
        print("Training completed! Best model loaded.")
        
        return self.history

print("Stable MetaBark model and trainer ready!")
print("Key features:")
print("- Ultra-low learning rate (5e-6)")
print("- Strong regularization (dropout 0.6)")
print("- Early stopping (patience 10)")
print("- Gradient clipping")
print("- Conservative architecture (256D features)")
print("- Frozen backbone layers for stability")

