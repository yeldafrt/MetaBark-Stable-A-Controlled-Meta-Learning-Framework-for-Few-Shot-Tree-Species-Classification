"""
Minimal Real Evaluation for MetaBark Stable
Get actual accuracy with minimal episodes
"""

import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
import numpy as np
import random
import json
import os
from PIL import Image
from torch.utils.data import Dataset

# Set seeds
torch.manual_seed(42)
np.random.seed(42)
random.seed(42)

# Minimal model definition
class StableMetaBark(torch.nn.Module):
    def __init__(self, feature_dim=256):
        super().__init__()
        from torchvision.models import resnet18, ResNet18_Weights
        self.backbone = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
        
        # Freeze layers
        for param in self.backbone.conv1.parameters():
            param.requires_grad = False
        for param in self.backbone.bn1.parameters():
            param.requires_grad = False
        for param in self.backbone.layer1.parameters():
            param.requires_grad = False
        for param in self.backbone.layer2.parameters():
            param.requires_grad = False
        
        self.backbone.fc = torch.nn.Identity()
        
        self.feature_processor = torch.nn.Sequential(
            torch.nn.Linear(512, feature_dim),
            torch.nn.BatchNorm1d(feature_dim),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.6),
            torch.nn.Linear(feature_dim, feature_dim),
            torch.nn.BatchNorm1d(feature_dim),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.5)
        )
        
        self.self_attention = torch.nn.MultiheadAttention(
            embed_dim=feature_dim, num_heads=4, dropout=0.3, batch_first=True
        )
        
        self.enhancer = torch.nn.Sequential(
            torch.nn.Linear(feature_dim, feature_dim),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.4),
            torch.nn.Linear(feature_dim, feature_dim)
        )
        
        self.temperature = torch.nn.Parameter(torch.tensor(5.0))
    
    def extract_features(self, x):
        features = self.backbone(x)
        processed = self.feature_processor(features)
        
        batch_size = processed.size(0)
        processed_reshaped = processed.unsqueeze(1)
        attended, _ = self.self_attention(processed_reshaped, processed_reshaped, processed_reshaped)
        attended = attended.squeeze(1)
        
        enhanced = self.enhancer(attended)
        final_features = processed + 0.5 * enhanced
        final_features = F.normalize(final_features, p=2, dim=1)
        
        return final_features
    
    def prototypical_forward(self, support_images, support_labels, query_images):
        support_features = self.extract_features(support_images)
        query_features = self.extract_features(query_images)
        
        unique_labels = torch.unique(support_labels)
        prototypes = []
        
        for label in unique_labels:
            mask = support_labels == label
            prototype = support_features[mask].mean(dim=0)
            prototypes.append(prototype)
        
        prototypes = torch.stack(prototypes)
        distances = torch.cdist(query_features, prototypes)
        temp = torch.clamp(self.temperature, min=1.0, max=10.0)
        logits = -distances / temp
        
        return logits

# Minimal dataset
class MinimalBarkDataset(Dataset):
    def __init__(self, data_dir, transform=None):
        self.data_dir = data_dir
        self.transform = transform
        self.images = []
        self.labels = []
        
        species_folders = [f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))]
        species_folders.sort()
        
        for species_idx, species_folder in enumerate(species_folders):
            species_path = os.path.join(data_dir, species_folder)
            for img_file in os.listdir(species_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(species_path, img_file)
                    self.images.append(img_path)
                    self.labels.append(species_idx)
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, label

def minimal_real_evaluation():
    """Get real accuracy with minimal episodes"""
    print("🔍 MINIMAL REAL EVALUATION - MetaBark Stable")
    print("=" * 50)
    
    # Load model
    model = StableMetaBark(feature_dim=256)
    checkpoint_path = '/home/ubuntu/metabark_stable_best.pth'
    
    if not os.path.exists(checkpoint_path):
        print("❌ Checkpoint not found!")
        return None
    
    model.load_state_dict(torch.load(checkpoint_path, map_location='cpu'))
    model.eval()
    print("✅ Model loaded successfully")
    
    # Simple transform
    transform = transforms.Compose([
        transforms.Resize((128, 128)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    # Load dataset
    data_dir = '/home/ubuntu/datasets/mini_barknet_real/BarkNet-mini'
    dataset = MinimalBarkDataset(data_dir, transform=transform)
    
    # Get validation species (same as training split)
    all_species = list(set([label for _, label in dataset]))
    val_species = all_species[8:10]  # Species 8 and 9
    
    print(f"📊 Validation species: {val_species}")
    
    # Filter validation data
    val_indices = [i for i, (_, label) in enumerate(dataset) if label in val_species]
    print(f"📊 Validation samples: {len(val_indices)}")
    
    # Minimal evaluation
    accuracies = []
    n_episodes = 5  # Very minimal
    n_way = 2
    n_shot = 3
    n_query = 2
    
    print(f"\n🧪 Running {n_episodes} episodes ({n_way}-way {n_shot}-shot)...")
    
    with torch.no_grad():
        for episode in range(n_episodes):
            try:
                # Sample episode
                support_images = []
                support_labels = []
                query_images = []
                query_labels = []
                
                for class_idx, species in enumerate(val_species):
                    # Get images for this species
                    species_indices = [i for i in val_indices if dataset.labels[i] == species]
                    
                    if len(species_indices) >= n_shot + n_query:
                        sampled_indices = random.sample(species_indices, n_shot + n_query)
                        
                        # Support set
                        for idx in sampled_indices[:n_shot]:
                            image, _ = dataset[idx]
                            support_images.append(image)
                            support_labels.append(class_idx)
                        
                        # Query set
                        for idx in sampled_indices[n_shot:n_shot + n_query]:
                            image, _ = dataset[idx]
                            query_images.append(image)
                            query_labels.append(class_idx)
                
                if len(support_images) == n_way * n_shot and len(query_images) == n_way * n_query:
                    # Convert to tensors
                    support_images = torch.stack(support_images)
                    support_labels = torch.tensor(support_labels)
                    query_images = torch.stack(query_images)
                    query_labels = torch.tensor(query_labels)
                    
                    # Forward pass
                    logits = model.prototypical_forward(support_images, support_labels, query_images)
                    
                    # Calculate accuracy
                    predictions = torch.argmax(logits, dim=1)
                    accuracy = (predictions == query_labels).float().mean().item()
                    
                    accuracies.append(accuracy * 100)
                    print(f"  Episode {episode+1}: {accuracy*100:.1f}%")
                
            except Exception as e:
                print(f"  Episode {episode+1} failed: {e}")
                continue
    
    if not accuracies:
        print("❌ No successful episodes!")
        return None
    
    # Calculate results
    mean_acc = np.mean(accuracies)
    std_acc = np.std(accuracies)
    
    print(f"\n🎯 REAL EVALUATION RESULTS:")
    print(f"=" * 50)
    print(f"Episodes Completed: {len(accuracies)}/{n_episodes}")
    print(f"Configuration: {n_way}-way {n_shot}-shot")
    print(f"Mean Accuracy: {mean_acc:.1f}% ± {std_acc:.1f}%")
    print(f"Individual Results: {[f'{acc:.1f}%' for acc in accuracies]}")
    
    # Save real results
    results = {
        'real_evaluation': {
            'mean_accuracy': mean_acc,
            'std_accuracy': std_acc,
            'episodes_completed': len(accuracies),
            'configuration': f"{n_way}-way {n_shot}-shot",
            'individual_accuracies': accuracies,
            'status': 'REAL_RESULTS'
        }
    }
    
    with open('/home/ubuntu/metabark_stable_REAL_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 REAL results saved to: metabark_stable_REAL_results.json")
    print(f"🎯 THIS IS THE ACTUAL PERFORMANCE!")
    
    return results

if __name__ == "__main__":
    results = minimal_real_evaluation()

